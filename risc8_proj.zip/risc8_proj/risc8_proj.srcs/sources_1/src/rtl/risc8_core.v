// =====================================================================
//  risc8_core.v  -  TOP: CPU RISC 8 bit, pipeline 5 tang (ISA v2)
//
//    IF  : lay lenh tai PC
//    ID  : giai ma + doc thanh ghi
//    EX  : forwarding, ALU, co Z/C, quyet dinh re nhanh
//    MEM : LD / ST
//    WB  : ghi ket qua vao regfile
//
//  Thanh ghi pipeline (tien to):  fd_ = IF/ID   de_ = ID/EX
//                                 em_ = EX/MEM  mw_ = MEM/WB
//
//  QUY UOC "BUBBLE": mot lenh rong co MOI bit co the thay doi trang thai
//  (reg_we, mem_we, flag_we, halt, br) bang 0 -> di qua pipeline ma khong
//  gay hai. Bubble duoc tao ra khi: re nhanh, HLT, load-use stall.
//
//  Uu tien cap nhat PC / IF-ID:  re nhanh > HLT > stall > binh thuong
// =====================================================================
`timescale 1ns/1ps

module risc8_core #(
    parameter ROM_FILE = "program.mem"
) (
    input  wire       clk,
    input  wire       rst,           // reset dong bo, muc cao
    output reg        halted,        // 1 sau khi HLT ra khoi pipeline
    output wire [7:0] pc_out,        // debug: PC
    output wire [1:0] flags_out,     // debug: {Z, C}
    output wire       instr_done     // debug: 1 khi mot lenh hoan tat WB
);
    // loai re nhanh (phai khop control_unit.v)
    localparam BR_NONE = 3'd0, BR_JMP = 3'd1, BR_Z = 3'd2,
               BR_NZ   = 3'd3, BR_C   = 3'd4, BR_NC = 3'd5;

    // -----------------------------------------------------------------
    //  Khai bao truoc tat ca thanh ghi (de cac tang phia truoc dung duoc)
    // -----------------------------------------------------------------
    reg [7:0]  pc;
    // IF/ID
    reg [15:0] fd_instr;
    reg        fd_valid;
    // ID/EX
    reg        de_valid;
    reg [3:0]  de_alu_op;
    reg        de_use_imm, de_uses_a, de_uses_b;
    reg        de_reg_we, de_is_load, de_mem_we, de_flag_we, de_halt;
    reg [2:0]  de_br;
    reg [2:0]  de_rd, de_ra, de_rb;
    reg [7:0]  de_a, de_b, de_imm;
    // EX/MEM
    reg        em_valid, em_reg_we, em_is_load, em_mem_we, em_halt;
    reg [2:0]  em_rd;
    reg [7:0]  em_alu, em_addr, em_sdata;
    // MEM/WB
    reg        mw_valid, mw_reg_we, mw_halt;
    reg [2:0]  mw_rd;
    reg [7:0]  mw_data;
    // co trang thai + co "da thay HLT"
    reg        flag_z, flag_c, draining;

    // =================================================================
    //  TANG 1 : IF
    // =================================================================
    wire [15:0] if_instr;

    imem #(.ROM_FILE(ROM_FILE)) u_imem (
        .addr  (pc),
        .instr (if_instr)
    );

    // =================================================================
    //  TANG 2 : ID
    // =================================================================
    wire [3:0] id_op    = fd_instr[15:12];
    wire [2:0] id_rd    = fd_instr[11:9];
    wire [2:0] id_rs1   = fd_instr[8:6];
    wire [2:0] id_rs2   = fd_instr[5:3];
    wire [2:0] id_funct = fd_instr[2:0];
    wire [7:0] id_imm   = fd_instr[7:0];

    wire [3:0] id_alu_op;
    wire       id_use_imm, id_a_from_rd, id_b_from_rd, id_uses_a, id_uses_b;
    wire       id_reg_we, id_is_load, id_mem_we, id_flag_we, id_halt;
    wire [2:0] id_br;

    control_unit u_cu (
        .opcode    (id_op),
        .funct     (id_funct),
        .alu_op    (id_alu_op),
        .use_imm   (id_use_imm),
        .a_from_rd (id_a_from_rd),
        .b_from_rd (id_b_from_rd),
        .uses_a    (id_uses_a),
        .uses_b    (id_uses_b),
        .reg_we    (id_reg_we),
        .is_load   (id_is_load),
        .mem_we    (id_mem_we),
        .flag_we   (id_flag_we),
        .br_kind   (id_br),
        .halt      (id_halt)
    );

    // ADDI/CMPI doc rd o cong A; ST doc rd (du lieu can luu) o cong B
    wire [2:0] id_ra = id_a_from_rd ? id_rd : id_rs1;
    wire [2:0] id_rb = id_b_from_rd ? id_rd : id_rs2;
    wire [7:0] id_a_data, id_b_data;

    regfile u_rf (
        .clk     (clk),
        .rst     (rst),
        .raddr_a (id_ra),  .rdata_a (id_a_data),
        .raddr_b (id_rb),  .rdata_b (id_b_data),
        // cong ghi: do tang WB dieu khien
        .we      (mw_reg_we),
        .waddr   (mw_rd),
        .wdata   (mw_data)
    );

    // =================================================================
    //  HAZARD UNIT
    // =================================================================
    wire [1:0] fwd_a, fwd_b;
    wire       stall;

    hazard_unit u_hz (
        .id_valid    (fd_valid),
        .id_ra       (id_ra),
        .id_rb       (id_rb),
        .id_uses_a   (id_uses_a),
        .id_uses_b   (id_uses_b),
        .ex_is_load  (de_is_load),
        .ex_rd       (de_rd),
        .ex_ra       (de_ra),
        .ex_rb       (de_rb),
        .ex_uses_a   (de_uses_a),
        .ex_uses_b   (de_uses_b),
        .mem_reg_we  (em_reg_we),
        .mem_is_load (em_is_load),
        .mem_rd      (em_rd),
        .wb_reg_we   (mw_reg_we),
        .wb_rd       (mw_rd),
        .fwd_a       (fwd_a),
        .fwd_b       (fwd_b),
        .stall       (stall)
    );

    // =================================================================
    //  TANG 3 : EX
    // =================================================================
    reg [7:0] ex_a, ex_b;           // toan hang sau forwarding
    always @(*) begin
        case (fwd_a)
            2'b10:   ex_a = em_alu;
            2'b01:   ex_a = mw_data;
            default: ex_a = de_a;
        endcase
        case (fwd_b)
            2'b10:   ex_b = em_alu;
            2'b01:   ex_b = mw_data;
            default: ex_b = de_b;
        endcase
    end

    wire [7:0] ex_alu_b = de_use_imm ? de_imm : ex_b;
    wire [7:0] alu_y;
    wire       alu_c, alu_z;

    alu u_alu (
        .a     (ex_a),
        .b     (ex_alu_b),
        .op    (de_alu_op),
        .y     (alu_y),
        .carry (alu_c),
        .zero  (alu_z)
    );

    // ---- Quyet dinh re nhanh (co Z/C da cap nhat boi lenh truoc) ----
    reg br_hit;
    always @(*) begin
        case (de_br)
            BR_JMP:  br_hit = 1'b1;
            BR_Z:    br_hit =  flag_z;
            BR_NZ:   br_hit = ~flag_z;
            BR_C:    br_hit =  flag_c;
            BR_NC:   br_hit = ~flag_c;
            default: br_hit = 1'b0;
        endcase
    end
    wire take_branch = de_valid && br_hit;

    // ---- HLT ----
    wire ex_halt    = de_valid && de_halt;
    wire fetch_stop = draining || ex_halt;

    // =================================================================
    //  TANG 4 : MEM
    // =================================================================
    wire [7:0] mem_rdata;

    dmem u_dmem (
        .clk   (clk),
        .we    (em_mem_we && !halted),
        .addr  (em_addr),
        .wdata (em_sdata),
        .rdata (mem_rdata)
    );

    wire [7:0] mem_result = em_is_load ? mem_rdata : em_alu;

    // =================================================================
    //  CAP NHAT THANH GHI (moi thanh ghi chi duoc gan trong MOT khoi always)
    // =================================================================

    // ---------- PC va IF/ID ----------
    always @(posedge clk) begin
        if (rst) begin
            pc       <= 8'h00;
            fd_instr <= 16'h0000;
            fd_valid <= 1'b0;
        end else if (!halted) begin
            if (take_branch) begin              // re nhanh: nhay + huy lenh sai duong
                pc       <= de_imm;
                fd_instr <= 16'h0000;
                fd_valid <= 1'b0;
            end else if (fetch_stop) begin      // HLT: khong lay lenh moi
                fd_instr <= 16'h0000;
                fd_valid <= 1'b0;
            end else if (!stall) begin          // binh thuong
                pc       <= pc + 8'd1;
                fd_instr <= if_instr;
                fd_valid <= 1'b1;
            end
            // stall: giu nguyen PC va IF/ID
        end
    end

    // ---------- ID/EX ----------
    always @(posedge clk) begin
        if (rst) begin
            de_valid  <= 1'b0;  de_alu_op <= 4'd0;
            de_use_imm <= 1'b0; de_uses_a <= 1'b0; de_uses_b <= 1'b0;
            de_reg_we <= 1'b0;  de_is_load <= 1'b0; de_mem_we <= 1'b0;
            de_flag_we <= 1'b0; de_halt <= 1'b0;    de_br <= BR_NONE;
            de_rd <= 3'd0; de_ra <= 3'd0; de_rb <= 3'd0;
            de_a <= 8'h00; de_b <= 8'h00; de_imm <= 8'h00;
        end else if (!halted) begin
            if (take_branch || fetch_stop || stall || !fd_valid) begin
                // BUBBLE: xoa moi bit co the gay thay doi trang thai
                de_valid   <= 1'b0;
                de_uses_a  <= 1'b0;  de_uses_b  <= 1'b0;
                de_reg_we  <= 1'b0;  de_is_load <= 1'b0;
                de_mem_we  <= 1'b0;  de_flag_we <= 1'b0;
                de_halt    <= 1'b0;  de_br      <= BR_NONE;
            end else begin
                de_valid   <= 1'b1;
                de_alu_op  <= id_alu_op;
                de_use_imm <= id_use_imm;
                de_uses_a  <= id_uses_a;   de_uses_b <= id_uses_b;
                de_reg_we  <= id_reg_we;   de_is_load <= id_is_load;
                de_mem_we  <= id_mem_we;   de_flag_we <= id_flag_we;
                de_halt    <= id_halt;     de_br      <= id_br;
                de_rd <= id_rd;  de_ra <= id_ra;  de_rb <= id_rb;
                de_a  <= id_a_data;  de_b <= id_b_data;  de_imm <= id_imm;
            end
        end
    end

    // ---------- EX/MEM + co Z/C + co draining ----------
    always @(posedge clk) begin
        if (rst) begin
            em_valid <= 1'b0; em_reg_we <= 1'b0; em_is_load <= 1'b0;
            em_mem_we <= 1'b0; em_halt <= 1'b0;  em_rd <= 3'd0;
            em_alu <= 8'h00; em_addr <= 8'h00;   em_sdata <= 8'h00;
            flag_z <= 1'b0;  flag_c <= 1'b0;     draining <= 1'b0;
        end else if (!halted) begin
            em_valid   <= de_valid;
            em_reg_we  <= de_reg_we;
            em_is_load <= de_is_load;
            em_mem_we  <= de_mem_we;
            em_halt    <= ex_halt;
            em_rd      <= de_rd;
            em_alu     <= alu_y;
            em_addr    <= ex_a;          // dia chi = R[rs1] (da forward)
            em_sdata   <= ex_b;          // du lieu ST = R[rd] (da forward)

            if (de_flag_we) begin        // bubble co de_flag_we = 0
                flag_z <= alu_z;
                flag_c <= alu_c;
            end
            if (ex_halt) draining <= 1'b1;
        end
    end

    // ---------- MEM/WB + halted ----------
    always @(posedge clk) begin
        if (rst) begin
            mw_valid <= 1'b0; mw_reg_we <= 1'b0; mw_halt <= 1'b0;
            mw_rd <= 3'd0;    mw_data <= 8'h00;  halted <= 1'b0;
        end else if (!halted) begin
            mw_valid  <= em_valid;
            mw_reg_we <= em_reg_we;
            mw_rd     <= em_rd;
            mw_data   <= mem_result;
            mw_halt   <= em_halt;
            if (mw_halt) halted <= 1'b1;   // HLT da toi WB: moi lenh truoc do xong
        end
    end

    // ---------- Ngo ra debug ----------
    assign pc_out     = pc;
    assign flags_out  = {flag_z, flag_c};
    assign instr_done = mw_valid;
endmodule
