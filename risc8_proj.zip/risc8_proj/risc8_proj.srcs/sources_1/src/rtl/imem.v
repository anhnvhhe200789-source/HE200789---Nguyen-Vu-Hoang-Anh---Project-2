// =====================================================================
//  imem.v  -  Bo nho lenh ROM 256 x 16 bit (doc bat dong bo)
//  Nap chuong trinh tu file .mem bang $readmemh.
//  (Trong Vivado hay dat ten file la program.mem va Add vao project.)
// =====================================================================
`timescale 1ns/1ps

module imem #(
    parameter ROM_FILE = "program.mem"
) (
    input  wire [7:0]  addr,
    output wire [15:0] instr
);
    reg [15:0] rom [0:255];
    integer k;

    initial begin
        for (k = 0; k < 256; k = k + 1)
            rom[k] = 16'h0000;            // o nho chua dung = NOP
        $readmemh(ROM_FILE, rom);
    end

    assign instr = rom[addr];
endmodule
