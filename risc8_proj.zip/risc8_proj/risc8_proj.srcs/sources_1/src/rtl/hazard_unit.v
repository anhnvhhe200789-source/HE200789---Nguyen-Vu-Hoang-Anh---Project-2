// =====================================================================
//  hazard_unit.v  -  Phat hien hazard du lieu (thuan to hop)
//
//  1) FORWARDING cho tang EX (moi toan hang A, B xet rieng):
//        2'b10 : lay ket qua ALU dang nam o EX/MEM (lenh truoc 1 lenh)
//        2'b01 : lay ket qua dang nam o MEM/WB     (lenh truoc 2 lenh)
//        2'b00 : dung gia tri doc o tang ID
//     (lenh truoc 3 lenh da duoc regfile bypass lo.)
//     EX/MEM duoc uu tien vi la gia tri MOI hon.
//
//  2) LOAD-USE STALL: LD dang o EX va lenh o ID can thanh ghi ma LD se ghi
//     -> dung PC + IF/ID 1 chu ky, chen bubble vao ID/EX.
// =====================================================================
`timescale 1ns/1ps

module hazard_unit (
    // lenh dang o ID
    input  wire       id_valid,
    input  wire [2:0] id_ra,
    input  wire [2:0] id_rb,
    input  wire       id_uses_a,
    input  wire       id_uses_b,
    // lenh dang o EX
    input  wire       ex_is_load,
    input  wire [2:0] ex_rd,
    input  wire [2:0] ex_ra,
    input  wire [2:0] ex_rb,
    input  wire       ex_uses_a,
    input  wire       ex_uses_b,
    // lenh dang o MEM
    input  wire       mem_reg_we,
    input  wire       mem_is_load,
    input  wire [2:0] mem_rd,
    // lenh dang o WB
    input  wire       wb_reg_we,
    input  wire [2:0] wb_rd,
    // ket qua
    output wire [1:0] fwd_a,
    output wire [1:0] fwd_b,
    output wire       stall
);
    // Chon nguon forward cho mot toan hang (dung chung cho A va B)
    function [1:0] pick_src;
        input       uses;      // toan hang nay co that su duoc doc khong
        input [2:0] src;       // so thanh ghi nguon
        input       m_we;
        input       m_ld;
        input [2:0] m_rd;
        input       w_we;
        input [2:0] w_rd;
        begin
            if (uses && m_we && !m_ld && (m_rd == src))
                pick_src = 2'b10;
            else if (uses && w_we && (w_rd == src))
                pick_src = 2'b01;
            else
                pick_src = 2'b00;
        end
    endfunction

    assign fwd_a = pick_src(ex_uses_a, ex_ra, mem_reg_we, mem_is_load, mem_rd, wb_reg_we, wb_rd);
    assign fwd_b = pick_src(ex_uses_b, ex_rb, mem_reg_we, mem_is_load, mem_rd, wb_reg_we, wb_rd);

    wire dep_a = id_uses_a && (id_ra == ex_rd);
    wire dep_b = id_uses_b && (id_rb == ex_rd);

    assign stall = id_valid && ex_is_load && (dep_a || dep_b);
endmodule
