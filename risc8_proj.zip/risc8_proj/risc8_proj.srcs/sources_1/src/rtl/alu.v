// =====================================================================
//  alu.v  -  ALU 8 bit cho RISC-8 v2
//  Moi phep toan deu tinh ra so 9 bit "wide":
//     wide[8]   -> co C (carry / borrow / bit bi day ra)
//     wide[7:0] -> ket qua y
//  Co Z = 1 khi y == 0.   Thuan to hop (khong clock).
// =====================================================================
`timescale 1ns/1ps

module alu (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire [3:0] op,
    output reg  [7:0] y,
    output reg        carry,
    output wire       zero
);
    localparam OP_ADD   = 4'd0,
               OP_SUB   = 4'd1,
               OP_AND   = 4'd2,
               OP_OR    = 4'd3,
               OP_XOR   = 4'd4,
               OP_SHL   = 4'd5,
               OP_SHR   = 4'd6,
               OP_PASSB = 4'd7,    // LDI: y = b
               OP_NOT   = 4'd8,    // NOT: y = ~a
               OP_PASSA = 4'd9;    // MOV: y = a

    reg [8:0] wide;

    always @(*) begin
        wide = 9'd0;                                   // mac dinh -> khong sinh latch
        case (op)
            OP_ADD  : wide = {1'b0, a} + {1'b0, b};
            OP_SUB  : wide = {1'b0, a} - {1'b0, b};    // wide[8]=1 <=> a < b (co muon)
            OP_AND  : wide = {1'b0, a & b};
            OP_OR   : wide = {1'b0, a | b};
            OP_XOR  : wide = {1'b0, a ^ b};
            OP_SHL  : wide = {a, 1'b0};                // bit day ra = a[7]
            OP_SHR  : wide = {a[0], 1'b0, a[7:1]};     // bit day ra = a[0]
            OP_PASSB: wide = {1'b0, b};
            OP_NOT  : wide = {1'b0, ~a};
            OP_PASSA: wide = {1'b0, a};
            default : wide = 9'd0;
        endcase
        y     = wide[7:0];
        carry = wide[8];
    end

    assign zero = (y == 8'd0);
endmodule
