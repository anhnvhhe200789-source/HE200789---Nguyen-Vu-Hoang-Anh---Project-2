// =====================================================================
//  control_unit.v  -  Giai ma lenh (tang ID) cho ISA v2
//  Dau vao : opcode [15:12] va funct [2:0] cua lenh.
//  Dau ra  : cac tin hieu dieu khien, se di theo lenh qua ID/EX -> EX/MEM -> MEM/WB.
//
//  Opcode: 0 NOP | 1 ALU(funct) | 2 SHL | 3 SHR | 4 LDI | 5 ADDI | 6 CMPI
//          7 LD  | 8 ST | 9 JMP | A BZ | B BNZ | C BC | D BNC | E (du tru=NOP) | F HLT
//  funct (opcode 1): 0 ADD | 1 SUB | 2 AND | 3 OR | 4 XOR | 5 CMP | 6 NOT | 7 MOV
// =====================================================================
`timescale 1ns/1ps

module control_unit (
    input  wire [3:0] opcode,
    input  wire [2:0] funct,
    output reg  [3:0] alu_op,      // phep toan ALU (xem alu.v)
    output reg        use_imm,     // 1: toan hang B cua ALU = imm8
    output reg        a_from_rd,   // 1: cong doc A doc thanh ghi rd (ADDI, CMPI)
    output reg        b_from_rd,   // 1: cong doc B doc thanh ghi rd (ST)
    output reg        uses_a,      // lenh that su dung cong A (cho hazard unit)
    output reg        uses_b,      // lenh that su dung cong B
    output reg        reg_we,      // ghi thanh ghi o WB
    output reg        is_load,     // du lieu ghi ve lay tu RAM (LD)
    output reg        mem_we,      // ghi RAM o MEM (ST)
    output reg        flag_we,     // cap nhat Z, C o EX
    output reg  [2:0] br_kind,     // loai re nhanh (xem ben duoi)
    output reg        halt
);
    // opcode
    localparam OP_NOP = 4'h0, OP_ALU = 4'h1, OP_SHL = 4'h2, OP_SHR = 4'h3,
               OP_LDI = 4'h4, OP_ADDI= 4'h5, OP_CMPI= 4'h6, OP_LD  = 4'h7,
               OP_ST  = 4'h8, OP_JMP = 4'h9, OP_BZ  = 4'hA, OP_BNZ = 4'hB,
               OP_BC  = 4'hC, OP_BNC = 4'hD, OP_HLT = 4'hF;
    // ma phep toan ALU (phai khop alu.v)
    localparam ALU_ADD = 4'd0, ALU_SUB = 4'd1, ALU_AND = 4'd2, ALU_OR  = 4'd3,
               ALU_XOR = 4'd4, ALU_SHL = 4'd5, ALU_SHR = 4'd6, ALU_PASSB = 4'd7,
               ALU_NOT = 4'd8, ALU_PASSA = 4'd9;
    // loai re nhanh (phai khop risc8_core.v)
    localparam BR_NONE = 3'd0, BR_JMP = 3'd1, BR_Z = 3'd2,
               BR_NZ   = 3'd3, BR_C   = 3'd4, BR_NC = 3'd5;

    always @(*) begin
        // ---- 1. mac dinh: moi thu tat (= NOP, dong thoi chong latch) ----
        alu_op = ALU_ADD;  use_imm = 1'b0;  a_from_rd = 1'b0; b_from_rd = 1'b0;
        uses_a = 1'b0;     uses_b  = 1'b0;  reg_we = 1'b0;    is_load = 1'b0;
        mem_we = 1'b0;     flag_we = 1'b0;  br_kind = BR_NONE; halt = 1'b0;

        // ---- 2. bat nhung gi tung lenh can ----
        case (opcode)
            OP_ALU: begin
                uses_a = 1'b1;  flag_we = 1'b1;  reg_we = 1'b1;
                case (funct)
                    3'd0: begin alu_op = ALU_ADD;  uses_b = 1'b1; end
                    3'd1: begin alu_op = ALU_SUB;  uses_b = 1'b1; end
                    3'd2: begin alu_op = ALU_AND;  uses_b = 1'b1; end
                    3'd3: begin alu_op = ALU_OR;   uses_b = 1'b1; end
                    3'd4: begin alu_op = ALU_XOR;  uses_b = 1'b1; end
                    3'd5: begin alu_op = ALU_SUB;  uses_b = 1'b1; reg_we = 1'b0; end // CMP
                    3'd6: begin alu_op = ALU_NOT;  end                               // NOT
                    3'd7: begin alu_op = ALU_PASSA; end                              // MOV
                endcase
            end
            OP_SHL : begin alu_op = ALU_SHL; uses_a = 1'b1; reg_we = 1'b1; flag_we = 1'b1; end
            OP_SHR : begin alu_op = ALU_SHR; uses_a = 1'b1; reg_we = 1'b1; flag_we = 1'b1; end
            OP_LDI : begin alu_op = ALU_PASSB; use_imm = 1'b1; reg_we = 1'b1; end
            OP_ADDI: begin alu_op = ALU_ADD; use_imm = 1'b1; a_from_rd = 1'b1;
                           uses_a = 1'b1; reg_we = 1'b1; flag_we = 1'b1; end
            OP_CMPI: begin alu_op = ALU_SUB; use_imm = 1'b1; a_from_rd = 1'b1;
                           uses_a = 1'b1; flag_we = 1'b1; end            // khong ghi reg
            OP_LD  : begin uses_a = 1'b1; reg_we = 1'b1; is_load = 1'b1; end
            OP_ST  : begin uses_a = 1'b1; uses_b = 1'b1; b_from_rd = 1'b1; mem_we = 1'b1; end
            OP_JMP : br_kind = BR_JMP;
            OP_BZ  : br_kind = BR_Z;
            OP_BNZ : br_kind = BR_NZ;
            OP_BC  : br_kind = BR_C;
            OP_BNC : br_kind = BR_NC;
            OP_HLT : halt = 1'b1;
            OP_NOP : ;        // NOP: giu mac dinh
            default: ;        // opcode du tru (E): coi nhu NOP
        endcase
    end
endmodule
