// =====================================================================
//  dmem.v  -  Bo nho du lieu RAM 256 x 8 bit
//  Doc: to hop (bat dong bo).  Ghi: dong bo, canh len clock.
//  Vivado se map vao distributed (LUT) RAM.
// =====================================================================
`timescale 1ns/1ps

module dmem (
    input  wire       clk,
    input  wire       we,
    input  wire [7:0] addr,
    input  wire [7:0] wdata,
    output wire [7:0] rdata
);
    reg [7:0] mem [0:255];
    integer k;

    initial begin
        for (k = 0; k < 256; k = k + 1)
            mem[k] = 8'h00;
    end

    always @(posedge clk) begin
        if (we)
            mem[addr] <= wdata;
    end

    assign rdata = mem[addr];
endmodule
