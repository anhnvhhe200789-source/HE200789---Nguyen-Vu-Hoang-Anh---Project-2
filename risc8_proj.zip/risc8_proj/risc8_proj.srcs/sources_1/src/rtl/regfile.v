// =====================================================================
//  regfile.v  -  8 thanh ghi x 8 bit, 2 cong doc (tang ID), 1 cong ghi (tang WB)
//  Co "write-through bypass": neu WB dang ghi dung thanh ghi ma ID dang doc
//  thi tra ve gia tri moi ngay -> xu ly hazard cach nhau 3 lenh.
// =====================================================================
`timescale 1ns/1ps

module regfile (
    input  wire       clk,
    input  wire       rst,          // reset dong bo, muc cao
    input  wire [2:0] raddr_a,
    output wire [7:0] rdata_a,
    input  wire [2:0] raddr_b,
    output wire [7:0] rdata_b,
    input  wire       we,
    input  wire [2:0] waddr,
    input  wire [7:0] wdata
);
    reg [7:0] regs [0:7];
    integer k;

    always @(posedge clk) begin
        if (rst) begin
            for (k = 0; k < 8; k = k + 1)
                regs[k] <= 8'h00;
        end else if (we) begin
            regs[waddr] <= wdata;
        end
    end

    wire hit_a = we && (waddr == raddr_a);
    wire hit_b = we && (waddr == raddr_b);

    assign rdata_a = hit_a ? wdata : regs[raddr_a];
    assign rdata_b = hit_b ? wdata : regs[raddr_b];
endmodule
