// =====================================================================
//  tb_regress.v - Kiem tra hoi quy bang chuong trinh NGAU NHIEN, ngay trong Vivado.
//  sw/gen_regress.py sinh:
//     regress_prog.mem : NPROG chuong trinh x 256 tu 16 bit
//     regress_exp.mem  : voi moi chuong trinh 266 byte dap an tu ISS
//                        (R0..R7, Z, C, RAM[0..255])
//  Testbench nap tung chuong trinh vao ROM, reset CPU, chay den HLT roi so sanh.
// =====================================================================
`timescale 1ns/1ps

module tb_regress;
    parameter NPROG = 200;          // phai bang so chuong trinh sinh boi gen_regress.py

    reg clk = 0, rst = 1;
    wire       halted;
    wire [7:0] pc;
    wire [1:0] flags;
    wire       done;

    risc8_core #(.ROM_FILE("program.mem")) dut (
        .clk(clk), .rst(rst), .halted(halted),
        .pc_out(pc), .flags_out(flags), .instr_done(done)
    );

    always #5 clk = ~clk;

    reg [15:0] prog_mem [0:NPROG*256-1];
    reg [7:0]  exp_mem  [0:NPROG*266-1];

    integer p, i, base, cyc, errors, bad_progs, prog_bad;

    initial begin
        errors = 0; bad_progs = 0;
        $readmemh("regress_prog.mem", prog_mem);
        $readmemh("regress_exp.mem",  exp_mem);

        for (p = 0; p < NPROG; p = p + 1) begin
            @(negedge clk);
            base = p * 266;
            prog_bad = 0;
            for (i = 0; i < 256; i = i + 1) begin
                dut.u_imem.rom[i] = prog_mem[p*256 + i];
                dut.u_dmem.mem[i] = 8'h00;
            end
            rst = 1;
            @(negedge clk); @(negedge clk);
            rst = 0;

            cyc = 0;
            while (!halted && cyc < 5000) begin
                @(negedge clk);
                cyc = cyc + 1;
            end
            @(negedge clk);

            if (!halted) begin
                $display("FAIL chuong trinh %0d: CPU khong dung (treo)", p);
                prog_bad = 1;
            end
            for (i = 0; i < 8; i = i + 1)
                if (dut.u_rf.regs[i] !== exp_mem[base + i]) begin
                    $display("FAIL prog %0d: R%0d = %02h, can %02h", p, i,
                             dut.u_rf.regs[i], exp_mem[base + i]);
                    prog_bad = 1;
                end
            if (flags[1] !== exp_mem[base+8][0] || flags[0] !== exp_mem[base+9][0]) begin
                $display("FAIL prog %0d: Z=%b C=%b, can Z=%b C=%b", p,
                         flags[1], flags[0], exp_mem[base+8][0], exp_mem[base+9][0]);
                prog_bad = 1;
            end
            for (i = 0; i < 256; i = i + 1)
                if (dut.u_dmem.mem[i] !== exp_mem[base + 10 + i]) begin
                    $display("FAIL prog %0d: MEM[%02h] = %02h, can %02h", p, i,
                             dut.u_dmem.mem[i], exp_mem[base + 10 + i]);
                    prog_bad = 1;
                end
            if (prog_bad) bad_progs = bad_progs + 1;
        end

        if (bad_progs == 0)
            $display("*** REGRESS: %0d chuong trinh ngau nhien, RTL khop ISS 100%% ***", NPROG);
        else
            $display("*** REGRESS: %0d / %0d chuong trinh SAI ***", bad_progs, NPROG);
        $finish;
    end
endmodule
