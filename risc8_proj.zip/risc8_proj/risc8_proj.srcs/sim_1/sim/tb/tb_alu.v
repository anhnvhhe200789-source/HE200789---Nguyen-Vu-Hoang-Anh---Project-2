// tb_alu.v - kiem tra ALU rieng le (tu dong PASS/FAIL)
`timescale 1ns/1ps

module tb_alu;
    reg  [7:0] a, b;
    reg  [3:0] op;
    wire [7:0] y;
    wire       carry, zero;
    integer    errors = 0;

    alu dut (.a(a), .b(b), .op(op), .y(y), .carry(carry), .zero(zero));

    task check(input [3:0] t_op, input [7:0] t_a, input [7:0] t_b,
               input [7:0] exp_y, input exp_c);
        begin
            op = t_op; a = t_a; b = t_b;
            #1;
            if (y !== exp_y || carry !== exp_c || zero !== (exp_y == 8'h00)) begin
                $display("FAIL op=%0d a=%02h b=%02h : y=%02h c=%b z=%b (can %02h %b)",
                         t_op, t_a, t_b, y, carry, zero, exp_y, exp_c);
                errors = errors + 1;
            end else
                $display("PASS op=%0d a=%02h b=%02h : y=%02h c=%b z=%b",
                         t_op, t_a, t_b, y, carry, zero);
        end
    endtask

    initial begin
        check(0, 8'hFF, 8'h01, 8'h00, 1);   // ADD tran
        check(0, 8'h10, 8'h20, 8'h30, 0);   // ADD thuong
        check(1, 8'h05, 8'h07, 8'hFE, 1);   // SUB co muon
        check(1, 8'h07, 8'h07, 8'h00, 0);   // SUB bang nhau
        check(2, 8'hF0, 8'h3C, 8'h30, 0);   // AND
        check(3, 8'hF0, 8'h0F, 8'hFF, 0);   // OR
        check(4, 8'hFF, 8'h0F, 8'hF0, 0);   // XOR
        check(5, 8'h81, 8'h00, 8'h02, 1);   // SHL, C = bit 7 cu
        check(6, 8'h03, 8'h00, 8'h01, 1);   // SHR, C = bit 0 cu
        check(7, 8'h00, 8'hAB, 8'hAB, 0);   // PASSB
        check(8, 8'h0F, 8'h00, 8'hF0, 0);   // NOT
        check(9, 8'h5A, 8'h00, 8'h5A, 0);   // PASSA
        if (errors == 0) $display("*** ALU: ALL PASS ***");
        else             $display("*** ALU: %0d FAIL ***", errors);
        $finish;
    end
endmodule
