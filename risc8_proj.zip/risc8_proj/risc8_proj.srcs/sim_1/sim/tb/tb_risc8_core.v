// =====================================================================
//  tb_risc8_core.v - Testbench chinh: chay program.mem, in pipeline moi chu ky,
//  kiem tra thanh ghi / RAM / co, thong ke CPI.
//  Gia tri mong doi duoc tinh tay tu sw/program.s (va doi chieu voi sw/iss.py).
// =====================================================================
`timescale 1ns/1ps

module tb_risc8_core;
    reg clk = 0, rst = 1;
    wire       halted;
    wire [7:0] pc;
    wire [1:0] flags;          // {Z, C}
    wire       done;

    risc8_core #(.ROM_FILE("program.mem")) dut (
        .clk(clk), .rst(rst), .halted(halted),
        .pc_out(pc), .flags_out(flags), .instr_done(done)
    );

    always #5 clk = ~clk;      // 100 MHz

    integer cycles = 0, retired = 0, stalls = 0, flushes = 0, fwds = 0, errors = 0;
    wire any_fwd = dut.de_valid && (dut.fwd_a != 2'b00 || dut.fwd_b != 2'b00);

    // ---- thong ke + in trang thai pipeline moi chu ky ----
    always @(posedge clk) if (!rst && !halted) begin
        cycles <= cycles + 1;
        if (done)             retired <= retired + 1;
        if (dut.stall)        stalls  <= stalls + 1;
        if (dut.take_branch)  flushes <= flushes + 1;
        if (any_fwd)          fwds    <= fwds + 1;
        $display("t=%5t PC=%02h | ID:%s%04h | EX:v%b | MEM:v%b | WB:%s R%0d<=%02h | Z=%b C=%b%s%s%s",
                 $time, pc, dut.fd_valid ? " " : "-", dut.fd_instr,
                 dut.de_valid, dut.em_valid,
                 dut.mw_reg_we ? "w" : "-", dut.mw_rd, dut.mw_data,
                 flags[1], flags[0],
                 dut.stall       ? " STALL"  : "",
                 dut.take_branch ? " FLUSH"  : "",
                 any_fwd         ? " fwd"    : "");
    end

    task check_reg(input [2:0] r, input [7:0] exp);
        begin
            if (dut.u_rf.regs[r] !== exp) begin
                $display("FAIL  R%0d = %02h, can %02h", r, dut.u_rf.regs[r], exp);
                errors = errors + 1;
            end else $display("PASS  R%0d = %02h", r, exp);
        end
    endtask

    task check_mem(input [7:0] addr, input [7:0] exp);
        begin
            if (dut.u_dmem.mem[addr] !== exp) begin
                $display("FAIL  MEM[%02h] = %02h, can %02h", addr, dut.u_dmem.mem[addr], exp);
                errors = errors + 1;
            end else $display("PASS  MEM[%02h] = %02h", addr, exp);
        end
    endtask

    initial begin
        #22 rst = 0;
        wait (halted);
        @(posedge clk); @(posedge clk);

        $display("\n------------- kiem tra ket qua -------------");
        check_reg(0, 8'h0F);  check_reg(1, 8'h00);
        check_reg(2, 8'h0F);  check_reg(3, 8'hFF);
        check_reg(4, 8'h2D);  check_reg(5, 8'hFF);
        check_reg(6, 8'h21);  check_reg(7, 8'h00);
        check_mem(8'h20, 8'h0F);
        check_mem(8'h21, 8'hFF);
        check_mem(8'h2D, 8'hFF);
        if (flags !== 2'b11) begin
            $display("FAIL  co Z=%b C=%b, can Z=1 C=1", flags[1], flags[0]);
            errors = errors + 1;
        end else $display("PASS  co Z=1 C=1");

        $display("\ncycles=%0d  instructions=%0d  CPI=%0.2f  load-use stalls=%0d  taken branches=%0d  forwarded=%0d",
                 cycles, retired, cycles * 1.0 / retired, stalls, flushes, fwds);
        if (errors == 0) $display("*** ALL TESTS PASSED ***");
        else             $display("*** %0d TEST(S) FAILED ***", errors);
        $finish;
    end

    initial begin #50000 $display("TIMEOUT"); $finish; end   // chong treo
endmodule
