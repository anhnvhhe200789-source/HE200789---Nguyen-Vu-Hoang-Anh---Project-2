// tb_regfile.v - kiem tra ghi / doc / bypass cua regfile
`timescale 1ns/1ps

module tb_regfile;
    reg        clk = 0, rst = 1, we = 0;
    reg  [2:0] ra = 0, rb = 0, wa = 0;
    reg  [7:0] wd = 0;
    wire [7:0] da, db;
    integer    errors = 0;

    regfile dut (.clk(clk), .rst(rst), .raddr_a(ra), .rdata_a(da),
                 .raddr_b(rb), .rdata_b(db), .we(we), .waddr(wa), .wdata(wd));

    always #5 clk = ~clk;

    task expect_eq(input [7:0] got, input [7:0] exp, input [127:0] name);
        begin
            if (got !== exp) begin
                $display("FAIL %0s: got %02h, can %02h", name, got, exp);
                errors = errors + 1;
            end else $display("PASS %0s = %02h", name, got);
        end
    endtask

    initial begin
        repeat (2) @(posedge clk);
        #1 rst = 0;

        // ghi R3 = A5, R6 = 5A
        we = 1; wa = 3; wd = 8'hA5; @(posedge clk); #1;
        wa = 6; wd = 8'h5A;          @(posedge clk); #1;
        we = 0;

        ra = 3; rb = 6; #1;
        expect_eq(da, 8'hA5, "doc R3");
        expect_eq(db, 8'h5A, "doc R6");

        // bypass: dang ghi R2 = 77 va doc R2 cung luc
        we = 1; wa = 2; wd = 8'h77; ra = 2; rb = 2; #1;
        expect_eq(da, 8'h77, "bypass cong A");
        expect_eq(db, 8'h77, "bypass cong B");
        @(posedge clk); #1 we = 0;

        // reset xoa het
        rst = 1; @(posedge clk); #1 rst = 0;
        ra = 3; rb = 2; #1;
        expect_eq(da, 8'h00, "R3 sau reset");
        expect_eq(db, 8'h00, "R2 sau reset");

        if (errors == 0) $display("*** REGFILE: ALL PASS ***");
        else             $display("*** REGFILE: %0d FAIL ***", errors);
        $finish;
    end
endmodule
