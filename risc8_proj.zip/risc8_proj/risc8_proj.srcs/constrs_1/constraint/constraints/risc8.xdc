# =====================================================================
#  risc8.xdc - Rang buoc cho board BASYS-3 (Artix-7 xc7a35tcpg236-1)
#  Neu dung board khac: chi can doi PACKAGE_PIN cho dung board cua ban.
# =====================================================================

# ---- Clock 100 MHz ----
set_property -dict { PACKAGE_PIN W5  IOSTANDARD LVCMOS33 } [get_ports clk]
create_clock -name sys_clk -period 10.000 [get_ports clk]

# ---- Reset: nut giua (BTNC), nhan = reset ----
set_property -dict { PACKAGE_PIN U18 IOSTANDARD LVCMOS33 } [get_ports rst]

# ---- pc_out[7:0] -> LED0..LED7 ----
set_property -dict { PACKAGE_PIN U16 IOSTANDARD LVCMOS33 } [get_ports {pc_out[0]}]
set_property -dict { PACKAGE_PIN E19 IOSTANDARD LVCMOS33 } [get_ports {pc_out[1]}]
set_property -dict { PACKAGE_PIN U19 IOSTANDARD LVCMOS33 } [get_ports {pc_out[2]}]
set_property -dict { PACKAGE_PIN V19 IOSTANDARD LVCMOS33 } [get_ports {pc_out[3]}]
set_property -dict { PACKAGE_PIN W18 IOSTANDARD LVCMOS33 } [get_ports {pc_out[4]}]
set_property -dict { PACKAGE_PIN U15 IOSTANDARD LVCMOS33 } [get_ports {pc_out[5]}]
set_property -dict { PACKAGE_PIN U14 IOSTANDARD LVCMOS33 } [get_ports {pc_out[6]}]
set_property -dict { PACKAGE_PIN V14 IOSTANDARD LVCMOS33 } [get_ports {pc_out[7]}]

# ---- flags_out[1:0] = {Z, C} -> LED8, LED9 ----
set_property -dict { PACKAGE_PIN V13 IOSTANDARD LVCMOS33 } [get_ports {flags_out[0]}]
set_property -dict { PACKAGE_PIN V3  IOSTANDARD LVCMOS33 } [get_ports {flags_out[1]}]

# ---- instr_done -> LED10 ; halted -> LED15 ----
set_property -dict { PACKAGE_PIN W3  IOSTANDARD LVCMOS33 } [get_ports instr_done]
set_property -dict { PACKAGE_PIN L1  IOSTANDARD LVCMOS33 } [get_ports halted]
